let button = document.getElementById("btn");
button.addEventListener("click",play1=>{
    const music = new Audio("singing-bowl-deep-sound-27532.mp3");
    music.play();
})
// function play1(){
//     console.log("leeo")
//     const music = new Audio("singing-bowl-deep-sound-27532.mp3");
//     console,log(music.play());
// }